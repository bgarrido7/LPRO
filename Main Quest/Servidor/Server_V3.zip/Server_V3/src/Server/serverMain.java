package Server;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.concurrent.TimeUnit;

import Client.*;

public class serverMain {
	
	public static void main(String args[]) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, InterruptedException {
		
		Thread mainServer=new Thread(new Server("localhost",9999));
		mainServer.start();
		System.out.println("mainServer"+mainServer.getName());
		
//		System.out.println(mainServer.toString());
	
		Thread client=new Thread(new Client("localhost",9999,"register","tu","tu","Tu","Tu"));
//		Thread client=new Thread(new Client("localhost",9999,"login","tu","tu"));
//		Thread client=new Thread(new Client("localhost",9999,"logout"));
//		Thread client=new Thread(new Client("localhost",9999,"editProfile","tu","tu"));
		Thread client1=new Thread(new Client("localhost",9999,"register","johnny1","jd1234","fgffgfgdf","fsdggsffg"));
		Thread client2=new Thread(new Client("localhost",9999,"register","johnny2","jd1235","zbfgxbbff","sdfjnkfdsjkn"));
		Thread client3=new Thread(new Client("localhost",9999,"register","johnny3","jd1236","fvfb fdzmguik","lknsdfajkd"));
//		client.setPriority(1);
		client.start();
		System.out.println("client"+client.getName());
//		TimeUnit.SECONDS.sleep(3);
//		client1.start();
//		System.out.println("client"+client1.getName());
//		client2.start();
//		client3.start();
		
		
	}
}