package Server;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;

public class GameLogic /*extends Server*/ implements Runnable {
	
	private SelectionKey player1Key,player2Key;//recebo
	private ByteBuffer[] results;//envio
	private boolean gameOver=false;//envio
	private int player1Rank;//recebo
	private int player2Rank;//recebo
	private String winner;//username
	private int turn;
	//variavel com nome da pe�a -> linked list com 2 slots para cada player, controla pe�a knocked out + pe�as no tabuleiro ->enviar para o cliente
	//inserir timer ->enviar entre cliente e servidor
	//deck dos jogadores
	//profile dos jogadores
	
	public GameLogic(SelectionKey player1Key,ByteBuffer[] buffer1,SelectionKey player2Key,ByteBuffer[] buffer2) throws IOException {
		
		this.player1Key=player1Key;
		this.player2Key=player2Key;
		SocketChannel player1Channel=(SocketChannel) player1Key.channel();
		String player1="Player1: "+player1Channel.getRemoteAddress();
		SocketChannel player2Channel=(SocketChannel) player2Key.channel();
		String player2="Player2: "+player2Channel.getRemoteAddress();
		//for player1 + player2
		System.out.println("Setting up match between "+player1+" and "+player2+".");
	}
	
	public void setTMPresults() {
		
		
	}
	
	public ByteBuffer[] getTMPresults() {
		
		return results;
	}

	@Override
	public void run() {//a.k.a. executa gameLogicStuff
		// TODO Auto-generated method stub
		
	}
}