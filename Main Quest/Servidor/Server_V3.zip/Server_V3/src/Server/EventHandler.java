package Server;
import java.io.IOException;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;

import manyClasses.*;

public class EventHandler {//colocar ByteBuffer "id"

	private final int ERROR=-1,REGISTER=0,LOGIN=1,LOGOUT=2,MATCHMAKING=3,CANCELMATCH=4,STORE=5,EDITPROFILE=6;
	private ArrayList<Object> outputObjects=new ArrayList<Object>();
	
	public ArrayList<Object> checkidRequest(SocketChannel clientChannel,ArrayList<Object> clientObjects,boolean session,String clientUsername) throws ClassNotFoundException, IOException {
	
		final int id=((Id) clientObjects.get(0)).getIdRequest();
		
		if(id==REGISTER)
			register(clientChannel,clientObjects);
		
		else if(id==LOGIN)
			login(clientChannel,clientObjects,session);
		
		else if(id==LOGOUT)
			logout(clientChannel,clientObjects);
		
		else if(id==EDITPROFILE) {
			
			editProfile(clientChannel,clientObjects,session,clientUsername);
		}
		
//		else if(id==MATCHMAKING)
//			matchmaking(clientChannel,clientObjects);
//		System.out.println(((Id)(outputObjects.get(0))).getIdRequest());
		return outputObjects;
	}
	
	public void register(SocketChannel clientChannel,ArrayList<Object> clientObjects) throws IOException, ClassNotFoundException {
		
		DatabaseAccess access=new DatabaseAccess();
		int output=-1;
		String username=((Register) clientObjects.get(1)).getUsername();
		String password=((Register) clientObjects.get(1)).getHash();
		String firstName=((Register) clientObjects.get(1)).getFirst();
		String lastName=((Register) clientObjects.get(1)).getLast();
		
		if(access.isValid(username)) {
			access.addUser(username,password,firstName,lastName);
			try {
				System.out.println("Cliente: "+clientChannel.getRemoteAddress()+" com o username: '"+username+"' foi registado.");
			} catch(IOException e) {
				e.printStackTrace();
			}
			output=REGISTER;
		}
		else {
			System.out.println("Username j� existe.");
			output=ERROR;
		}
	
		Id newIdRequest=new Id(output);
		outputObjects.add(newIdRequest);
		
		return;
	}	
	
	public void login(SocketChannel clientChannel,ArrayList<Object> clientObjects,boolean activeSession) throws IOException {
		
		DatabaseAccess access=new DatabaseAccess();
		Id newIdRequest;
		UserProfile userprofile;
		String username=((Login) clientObjects.get(1)).getUsername();
		String hash=((Login) clientObjects.get(1)).getHash();
		
		if(activeSession) {
			newIdRequest=new Id(-1);
			outputObjects.add(newIdRequest);
		}
		
		else if(access.validadeUser(username,hash)) {
			newIdRequest=new Id(1);
			userprofile=access.fetchUserProfile(username);
			outputObjects.add(newIdRequest);
			outputObjects.add(userprofile);
		}
		
		else {
			newIdRequest=new Id(-1);
			outputObjects.add(newIdRequest);
		}
		
		return;
	}
	
	public void logout(SocketChannel clientChannel,ArrayList<Object> clientObjects) throws IOException {
		
		
		
		return;
	}
	
	public void editProfile(SocketChannel clientChannel,ArrayList<Object> clientObjects,boolean activeSession,String clientUsername) {
		
		DatabaseAccess access=new DatabaseAccess();
		Id newIdRequest;
		String username=((Login) clientObjects.get(1)).getUsername();
		String hash=((Login) clientObjects.get(1)).getHash();
		
		if(!activeSession || access.isValid(clientUsername)) {
			newIdRequest=new Id(-1);
			outputObjects.add(newIdRequest);
		}
		
		else {
			access.alterProfile(username,hash,clientUsername);
			newIdRequest=new Id(EDITPROFILE);
			outputObjects.add(newIdRequest);
		}
	}
}