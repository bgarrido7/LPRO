/*
package Server;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;

public class serverRead implements Runnable {

	private SocketChannel clientChannel;

	public void run() {
		// TODO Auto-generated method stub
		EventHandler handler=new EventHandler();
		ArrayList<Object> clientOutput=new ArrayList<Object>();
		boolean checkSession;
		Server n=new Server("localhost",9999);
		try {
			checkSession=n.getClientSession(clientChannel.getRemoteAddress());
			System.out.println(checkSession);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		try {
			checkSession = getClientSession(clientChannel.getRemoteAddress());
			System.out.println(checkSession);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			SocketAddress clientAddress=clientChannel.getRemoteAddress();
			checkSession=getClientSession(clientAddress);
			checkActionAndRead(clientChannel);
			clientOutput=handler.checkidRequest(clientChannel,getClientOutputData(clientAddress),checkSession);
			setClientOutputData(clientAddress,clientOutput);
			set_OP_Permission(clientChannel.getRemoteAddress(),true);
			
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Exiting");
	}
}
*/