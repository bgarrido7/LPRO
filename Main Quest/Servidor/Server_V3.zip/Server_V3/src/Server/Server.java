package Server;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import manyClasses.*;

public class Server implements Runnable {
	
	final int REGISTER=0,LOGIN=1,LOGOUT=2,EDITPROFILE=6;
	private Selector serverSelector;
	private ServerSocketChannel serverSocket;
	private InetSocketAddress serverAddress;
	private HashMap<SocketAddress,Boolean> dataMapSession;
	private HashMap<SocketAddress,ArrayList<Object>> dataMapOutput;
	private HashMap<SocketAddress,Boolean> dataMapOngoingThread;
	private HashMap<SocketAddress,Boolean> dataMapChange_OP;
	private HashMap<SocketAddress,String> dataMapClientUsername;
	private final Object lock=new Object();
	
	public Server(String host,int port) {
		
		this.serverAddress=new InetSocketAddress(host,port);
	}
	
	public void run() {	
		try {
			serverSelector=Selector.open();
			serverSocket=ServerSocketChannel.open();
			serverSocket.configureBlocking(false);
			serverSocket.bind(serverAddress);
			serverSocket.register(serverSelector, SelectionKey.OP_ACCEPT);
			dataMapSession=new HashMap<>();
			dataMapOutput=new HashMap<>();
			dataMapOngoingThread=new HashMap<>();
			dataMapChange_OP=new HashMap<>();
			dataMapClientUsername=new HashMap<>();
			System.out.println("Servidor iniciado.");
		
			while(true) {
			
				int ready=serverSelector.select();
				Iterator<SelectionKey> serverIteration=serverSelector.selectedKeys().iterator();
				
				if(ready==0)
					continue;
				
				while(serverIteration.hasNext()) {
					
					SelectionKey singleKey= (SelectionKey) serverIteration.next();
					
					if (!singleKey.isValid()) 
	                    continue;
					
					if (singleKey.isAcceptable()) 
						accept(singleKey);
				
					else if (singleKey.isReadable())
						read(singleKey);
					
					else if (singleKey.isWritable())
						write(singleKey);
					
					serverIteration.remove();
				}
				
			}
		} catch (IOException | InterruptedException e){
				e.printStackTrace();
			}
	}

	private void accept(SelectionKey singleKey) throws IOException {
		// TODO Auto-generated method stub
		SocketChannel clientChannel=serverSocket.accept();
		System.out.println("Conex�o estabelecida com: "+clientChannel.getRemoteAddress());
		clientChannel.configureBlocking(false);
		clientChannel.register(serverSelector,SelectionKey.OP_READ);
		setClientOutputData(clientChannel.getRemoteAddress(),null);
		setClientSession(clientChannel.getRemoteAddress(),false);
		setOnGoingThread(clientChannel.getRemoteAddress(), false);
		set_OP_Permission(clientChannel.getRemoteAddress(), false);
		setClientUsername(clientChannel.getRemoteAddress(),null);
	}

	private void read(SelectionKey singleKey) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		SocketChannel clientChannel=(SocketChannel) singleKey.channel();
		
		if(!getOnGoingThread(clientChannel.getRemoteAddress())) {
			
			Runnable myReadRunnable=createReadRunnable(clientChannel);
			Thread read=new Thread(myReadRunnable);
			
			System.out.println(read.getName());
			read.start();
			read.join();
		}
		
		if(get_OP_Permission(clientChannel.getRemoteAddress())) {
			setOnGoingThread(clientChannel.getRemoteAddress(),false);
			clientChannel.register(serverSelector,SelectionKey.OP_WRITE);
			set_OP_Permission(clientChannel.getRemoteAddress(),false);
		}
	}

	private void write(SelectionKey singleKey) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		SocketChannel clientChannel=(SocketChannel) singleKey.channel();
		
		if(getClientOutputData(clientChannel.getRemoteAddress())==null) {
			System.out.println("Erro: nada para escrever. (NULL)");
			return;
		}
		
		if(!getOnGoingThread(clientChannel.getRemoteAddress())) {
			Runnable myWriteRunnable=createWriteRunnable(clientChannel);
			Thread write=new Thread(myWriteRunnable);
			System.out.println(write.getName());
			write.start();
		}
		
//		if(get_OP_Permission(clientChannel.getRemoteAddress())) {
//			setOnGoingThread(clientChannel.getRemoteAddress(),false);
//			clientChannel.register(serverSelector,SelectionKey.OP_READ);
//			set_OP_Permission(clientChannel.getRemoteAddress(),false);
//		}
	}

	
/*	
	public void checkRequest(int idRequest,SelectionKey singleKey) throws IOException {
				
		int id=buf.asIntBuffer().get();
		SocketChannel myChannel=(SocketChannel) singleKey.channel();
		
		
		
		if(id==3) {//adicionar � lista de match making
			waitingForGame_SelectionKey.addFirst(singleKey);//chave do cliente
			ByteBuffer[] bufferArray= {a preencher com base na l�gica de jogo};
			
			try {
				myChannel.read(bufferArray);//l� restantes byte buffers do pedido do cliente
				
			} catch(IOException e) {
				e.printStackTrace();
			}
			
			waitingForGame_Buffers.addFirst(bufferArray);
			
			if(waitingForGame_SelectionKey.size()>=2) {
				Thread gameStart=new Thread(new GameLogic(waitingForGame_SelectionKey.pollLast(),waitingForGame_Buffers.pollLast(),waitingForGame_SelectionKey.pollLast(),waitingForGame_Buffers.pollLast()));
				gameStart.start();
//				gamesInSession.add(gameStart);
			}
		}
		
		else if(id==4) {//cancelar match making -- errado!
			waitingForGame_SelectionKey.removeLast();
			waitingForGame_Buffers.removeLast();
		}
		
		myChannel.register(this.serverSelector, SelectionKey.OP_WRITE);
			
	}
*/	
	
	private synchronized String getClientUsername(SocketAddress clientAddress) throws IOException {
		
		String username;
		
		synchronized (lock) {
			username=dataMapClientUsername.get(clientAddress);
		}

		return username;
	}
	
	private synchronized void setClientUsername(SocketAddress clientAddress,String username) throws IOException {
		
		synchronized (lock) {
			dataMapClientUsername.put(clientAddress, username);
		}
	}
	
	private synchronized boolean getClientSession(SocketAddress clientAddress) throws IOException {
		
		boolean activeSession;
		
		synchronized (lock) {
			activeSession=dataMapSession.get(clientAddress);
		}

		return activeSession;
	}
	
	private synchronized void setClientSession(SocketAddress clientAddress,boolean activeSession) throws IOException {
		
		synchronized (lock) {
			dataMapSession.put(clientAddress, activeSession);
		}
	}
	
	private synchronized ArrayList<Object> getClientOutputData(SocketAddress clientAddress) throws IOException {
		
		ArrayList<Object> output;
		
		synchronized (lock) {
			output=dataMapOutput.get(clientAddress);
		}

		return output;
	}
	
	private synchronized void setClientOutputData(SocketAddress clientAddress,ArrayList<Object> clientArrayBuffer) throws IOException {
		
		synchronized (lock) {
			dataMapOutput.put(clientAddress, clientArrayBuffer);
		}
	}
	
	private synchronized Boolean get_OP_Permission(SocketAddress clientAddress) throws IOException {
		
		boolean permission;
		
		synchronized (lock) {
			permission=dataMapChange_OP.get(clientAddress);
		}

		return permission;
	}
	
	private synchronized void set_OP_Permission(SocketAddress clientAddress,boolean permission) throws IOException {
		
		synchronized (lock) {
			dataMapChange_OP.put(clientAddress, permission);
		}
	}
	
	private synchronized boolean getOnGoingThread(SocketAddress clientAddress) throws IOException {
		
		boolean access;
		
		synchronized (lock) {
			access=dataMapOngoingThread.get(clientAddress);
		}

		return access;
	}
	
	private synchronized void setOnGoingThread(SocketAddress clientAddress,boolean access) throws IOException {
		
		synchronized (lock) {
			dataMapOngoingThread.put(clientAddress, access);
		}
	}

	private Runnable createReadRunnable(SocketChannel clientChannel) throws IOException{
		
		Runnable aRunnable=new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				EventHandler handler=new EventHandler();
				ArrayList<Object> clientOutput=new ArrayList<Object>();
				boolean checkSession;
				String clientUsername;
				
				try {
					SocketAddress clientAddress=clientChannel.getRemoteAddress();
					checkSession=getClientSession(clientAddress);
					clientUsername=getClientUsername(clientChannel.getRemoteAddress());
					checkActionAndRead(clientChannel);
					clientOutput=handler.checkidRequest(clientChannel,getClientOutputData(clientAddress),checkSession,clientUsername);
					setClientOutputData(clientAddress,clientOutput);
					set_OP_Permission(clientChannel.getRemoteAddress(),true);
					
					} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Exiting");
			}
			
		};
		
		setOnGoingThread(clientChannel.getRemoteAddress(),true);	
		return aRunnable;
	}
	
	private Runnable createWriteRunnable(SocketChannel clientChannel) throws IOException {
		
		Runnable aRunnable=new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				ArrayList<Object> clientOutput=new ArrayList<Object>();

				try {
					clientOutput=getClientOutputData(clientChannel.getRemoteAddress());
					
					for(int i=0;i<clientOutput.size();i++) {
						sendObject(clientChannel,clientOutput.get(i));
						TimeUnit.MILLISECONDS.sleep(100);
					}
					
					set_OP_Permission(clientChannel.getRemoteAddress(),true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		
		setOnGoingThread(clientChannel.getRemoteAddress(),true);
		return aRunnable;
	}

	protected void checkActionAndRead(SocketChannel clientChannel) throws ClassNotFoundException, IOException, InterruptedException {
		
		Object tmpObj=recvObject_IdType(clientChannel);
		
		int id=((Id) tmpObj).getIdRequest();
		System.out.println(id);
		TimeUnit.MILLISECONDS.sleep(200);
		Object tmpObj2=recvObject_otherType(clientChannel,id);
		
		if(tmpObj==null || tmpObj2==null)
			return;
		
		ArrayList<Object> clientObjects=new ArrayList<Object>();
		clientObjects.add(tmpObj);
		clientObjects.add(tmpObj2);
		setClientOutputData(clientChannel.getRemoteAddress(),clientObjects);
		
		return;
	}

	private Object recvObject_IdType(SocketChannel clientChannel) throws IOException, ClassNotFoundException {
		
		ByteBuffer data = ByteBuffer.allocate(100);
		int numRead=clientChannel.read(data);
		if(numRead==0)
			return null;
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data.array());
		ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
		Id recvObject = (Id)objectInputStream.readObject();
		
		objectInputStream.close();
		return recvObject;
	}
	
	private Object recvObject_otherType(SocketChannel clientChannel, int id) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Object recvObject1=null;
		ByteBuffer data = ByteBuffer.allocate(500);
		int numRead=clientChannel.read(data);
		if(numRead==0)
			return null;
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data.array());
		ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
		
		if(id==REGISTER) {
			Register recvObject=null;
			recvObject = (Register)objectInputStream.readObject();
			return recvObject;
		}
		
		else if(id==LOGIN){
			Login recvObject=null;
			recvObject = (Login)objectInputStream.readObject();
			setClientUsername(clientChannel.getRemoteAddress(),recvObject.getUsername());
			return recvObject;
		}
		
		else if(id==LOGOUT){
//			Logout recvObject=null;
//			recvObject = (Logout)objectInputStream.readObject();
		}
		
		else if(id==EDITPROFILE) {
			
			Login recvObject=null;
			recvObject = (Login)objectInputStream.readObject();
			return recvObject;
		}
		
		objectInputStream.close();
		return recvObject1;
	}
	
	private void sendObject(SocketChannel clientChannel,Object sendObject) throws IOException {
		
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
		objectOutputStream.writeObject(sendObject);
		objectOutputStream.flush();
		clientChannel.write(ByteBuffer.wrap(byteArrayOutputStream.toByteArray()));	
	}
}

