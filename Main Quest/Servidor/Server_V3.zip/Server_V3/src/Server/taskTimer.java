package Server;

import java.util.Timer;
import java.util.TimerTask;

public class taskTimer {
	 
	int seconds=60;
	
	Timer myTimer =new Timer();
	TimerTask task=new TimerTask() {
		
		public void run() {
			seconds=seconds-10;
			System.out.print(seconds);
			if(seconds==0)
				myTimer.cancel();
		}
	};
	
	public void start() {
		
		myTimer.schedule(task,1000,10000);
	}
	
	public static void main(String[] args) {
		
		taskTimer tasking=new taskTimer();
		System.out.print("Timer: ");
		tasking.start();
	}
}
