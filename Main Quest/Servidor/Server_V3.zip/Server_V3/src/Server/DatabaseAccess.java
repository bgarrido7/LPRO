package Server;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

import manyClasses.UserProfile;

public class DatabaseAccess {

	private final String url = "jdbc:postgresql://dbm.fe.up.pt:5432/sibd1806?currentSchema=lpro_test";
	private final String admin_user = "sibd1806";
	private final String admin_pass = "2018";
	
	public void connectToDatabase() {
		
		Connection conn=null;
		Statement stmt=null;
		
		try {
			conn=DriverManager.getConnection(url, admin_user, admin_pass);
			System.out.println("Liga��o a 'dbm.fe.up.pt' conclu�da.");
			
			DatabaseMetaData meta=conn.getMetaData();
			ResultSet result=meta.getTables(null,null,"users",null);
			
			if(result.next()==false) {
				stmt=conn.createStatement();
            	String database="";
            	stmt.executeUpdate(database);
            	stmt.close();
            
            	System.out.println("Base de dados criada.");
			}
			else
				System.out.println("Base de dados j� existe.");
			
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public Boolean isValid(String username) {
		
		Connection conn=null;
		Statement stmt=null;
		Boolean check=false;
		
		try {
			conn=DriverManager.getConnection(url, admin_user, admin_pass);
			conn.setAutoCommit(false);
			stmt=conn.createStatement();
//			System.out.println(username);
//			System.out.println("SELECT username FROM users WHERE users.username = '"+username+"';");
			ResultSet result=stmt.executeQuery("SELECT username FROM users WHERE users.username = '"+username+"';");
//			System.out.println(result.next());
			
			if(result.isBeforeFirst()==false)
				check=true;
			else
				check=false;
			
			result.close();
			stmt.close();
			conn.commit();
			conn.close();
			
		} catch(SQLException e) {
//			e.printStackTrace();
			System.out.println("Sem liga��o � base de dados.");
			System.out.println("Servidor pifou.");
			System.exit(-1);
		}
		
		return check;
	}
	
	public void addUser(String username,String hash,String firstname,String lastname) {
		
		Connection conn=null;
		Statement stmt=null;
		
		try {
			conn=DriverManager.getConnection(url, admin_user, admin_pass);
			conn.setAutoCommit(false);
			stmt=conn.createStatement();
			int userId=0;
			
			String sql="INSERT INTO users (username,pass)"+"VALUES ('"+username+"','"+hash+"');";
			stmt.executeUpdate(sql);
			
			ResultSet result=stmt.executeQuery("SELECT userid FROM users WHERE users.username='"+username+"';");
			while(result.next()) {
				userId=result.getInt("userid");
			}
			result.close();
			
			sql="INSERT INTO userprofile (userid,firstname,lastname,league,coins,maxcharacters,totalduels,totalwins,bestwinstreak,highestrank,currentrank) VALUES ("+userId+",'"+firstname+"','"+lastname+"','thugLife',NULL,NULL,0,0,0,0,0);";
			stmt.executeUpdate(sql);
			
			stmt.close();
			conn.commit();
			conn.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public boolean validadeUser(String username,String hash) {
		
		Connection conn=null;
		Statement stmt=null;
		Boolean check=false;
		String tablePassword=null;
		
		try {
			conn=DriverManager.getConnection(url, admin_user, admin_pass);
			conn.setAutoCommit(false);
			stmt=conn.createStatement();
			ResultSet result=stmt.executeQuery("SELECT pass FROM users WHERE username = '"+username+"';");
		
			while(result.next()) {
				tablePassword=result.getString("pass");
			}
			
			result.close();
			stmt.close();
			conn.commit();
			conn.close();
			
			} catch(SQLException e) {
				e.printStackTrace();
			}
		
		if(Objects.equals(hash,tablePassword))
			check=true;
		
		else
			check=false;
		
		return check;
	}
	
	public UserProfile fetchUserProfile(String username) {
		
		Connection conn=null;
		Statement stmt=null;
		int userID=0;
		String first = null,last = null,league = null;
		int coins = 0,totalwins = 0,totalduels = 0,bestwinstreak = 0,highestrank = 0,currentrank = 0;
		
		try {
			conn=DriverManager.getConnection(url, admin_user, admin_pass);
			conn.setAutoCommit(false);
			stmt=conn.createStatement();
			ResultSet result1=stmt.executeQuery("SELECT userid FROM users WHERE username='"+username+"';");
			
			while(result1.next()) {
				userID=result1.getInt("userid");
			}
			
			ResultSet result=stmt.executeQuery("SELECT * FROM userprofile WHERE userprofile.userid="+userID+";");
			
			while(result.next()) {
				first=result.getString("firstname");
				last=result.getString("lastname");
				league=result.getString("league");
				coins=result.getInt("coins");
				//max characters??? ??? 1*10+2*90+3*51
				totalduels=result.getInt("totalduels");
				totalwins=result.getInt("totalwins");
				bestwinstreak=result.getInt("bestwinstreak");
				highestrank=result.getInt("highestrank");
				currentrank=result.getInt("currentrank");
			}
			
			result.close();
			stmt.close();
			conn.commit();
			conn.close();
			
			} catch(SQLException e) {
				e.printStackTrace();
			}

		UserProfile userprofile=new UserProfile(first,last,league,coins,totalduels,totalwins,bestwinstreak,highestrank,currentrank);
		String maxCharacterString="1,2,3,4,5,12,34,56,67,78,89,112,134,150,151";
		
		return userprofile;
	}
	
	public void alterProfile(String username,String password,String previousUsername) {
		
		Connection conn=null;
		Statement stmt=null;
		int userId=0;
		
		try {
			conn=DriverManager.getConnection(url, admin_user, admin_pass);
			conn.setAutoCommit(false);
			stmt=conn.createStatement();
			
			ResultSet result=stmt.executeQuery("SELECT userid FROM users WHERE users.username='"+previousUsername+"';");
			while(result.next()) {
				userId=result.getInt("userid");
			}
			result.close();
			
			String sql="UPDATE users SET username= '"+username+"' WHERE userid="+userId+";";
			stmt.executeUpdate(sql);
			sql="UPDATE users SET pass= '"+password+"' WHERE userid='"+userId+"';";
			stmt.executeUpdate(sql);
			
			stmt.close();
			conn.commit();
			conn.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
}