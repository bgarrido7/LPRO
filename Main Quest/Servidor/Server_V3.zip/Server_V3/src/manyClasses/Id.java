package manyClasses;

import java.io.Serializable;

public class Id implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6067658709303556655L;
	int idRequest;
	
	public Id(int id) {
		
		this.idRequest=id;
	}
	
	public int getIdRequest() {
		return idRequest;
	}
	public void setIdRequest(int idRequest) {
		this.idRequest = idRequest;
	}
}
