package manyClasses;

import java.io.Serializable;

public class Register implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -77336049094901682L;
	private String username;
	private String hash;
	private String first;
	private String last;
	
	public Register(String user,String hash,String first,String last) {
		
		this.username=user;
		this.hash=hash;
		this.first=first;
		this.last=last;
	}
	
	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getLast() {
		return last;
	}

	public void setLast(String last) {
		this.last = last;
	}
	
	public String getUsername() {
		
		return username;
	}
	
	public String getHash() {
		
		return hash;
	}
	
	public void setUsername(String user) {
		
		this.username=user;
	}
	
	public void setHash(String hash) {
	
		this.hash=hash;
	}
}
