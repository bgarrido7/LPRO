package manyClasses;

public class Omega {

	int idRequest;
	private String username;
	private String hash;
	private String first;
	private String last;
	
	public Omega(int id,String user,String hash,String first,String last) {//registo ou editar perfil
		
		this.username=user;
		this.hash=hash;
		this.first=first;
		this.last=last;
	}
	
	public Omega(String user,String hash) {//login
		
		this.username=user;
		this.hash=hash;
	}
	
	public Omega(int id) {//matchmaking
		
		this.idRequest=id;
	}
	
	//logout???
	
	public int getIdRequest() {
		return idRequest;
	}
	
	public String getFirst() {
		return first;
	}

	public String getLast() {
		return last;
	}
	
	public String getUsername() {
		
		return username;
	}
	
	public String getHash() {
		
		return hash;
	}
}
