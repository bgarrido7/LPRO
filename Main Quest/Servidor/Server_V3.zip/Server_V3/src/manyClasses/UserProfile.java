package manyClasses;

import java.io.Serializable;

public class UserProfile implements Serializable {//ap�s login e match

	/**
	 * 
	 */
	private static final long serialVersionUID = 7158680604178734828L;
	private String first;
	private String last;
	private String league;
	private int coins;
	private int maxcharacters;
	private int totalduels;
	private int totalwins;
	private int bestwinstreak;
	private int highestrank;
	private int currentrank;
	
	public UserProfile(String first, String last, String league, int coins, int totalduels, int totalwins,int bestwinstreak, int highestrank, int currentrank) {

		this.first = first;
		this.last = last;
		this.league = league;
		this.coins = coins;
		this.totalduels = totalduels;
		this.totalwins = totalwins;
		this.bestwinstreak = bestwinstreak;
		this.highestrank = highestrank;
		this.currentrank = currentrank;
	}
	
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	public String getLeague() {
		return league;
	}
	public void setLeague(String league) {
		this.league = league;
	}
	public int getCoins() {
		return coins;
	}
	public void setCoins(int coins) {
		this.coins = coins;
	}
	public int getMaxcharacters() {
		return maxcharacters;
	}
	public void setMaxcharacters(int maxcharacters) {
		this.maxcharacters = maxcharacters;
	}
	public int getTotalduels() {
		return totalduels;
	}
	public void setTotalduels(int totalduels) {
		this.totalduels = totalduels;
	}
	public int getTotalwins() {
		return totalwins;
	}
	public void setTotalwins(int totalwins) {
		this.totalwins = totalwins;
	}
	public int getBestwinstreak() {
		return bestwinstreak;
	}
	public void setBestwinstreak(int bestwinstreak) {
		this.bestwinstreak = bestwinstreak;
	}
	public int getHighestrank() {
		return highestrank;
	}
	public void setHighestrank(int highestrank) {
		this.highestrank = highestrank;
	}
	public int getCurrentrank() {
		return currentrank;
	}
	public void setCurrentrank(int currentrank) {
		this.currentrank = currentrank;
	}
}
