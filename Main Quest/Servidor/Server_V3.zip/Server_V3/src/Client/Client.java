package Client;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import manyClasses.*;

public class Client implements Runnable {
	
	final int ERROR=-1,REGISTER=0,LOGIN=1,LOGOUT=2,EDITPROFILE=6;
	private String action,username,password,hash,first,last;
	private InetSocketAddress serverAddress;
	
	public Client(String host,int port,String action,String username,String password,String first,String last) {//registo
		
		this.username=username;
		this.password=password;
		this.first=first;
		this.last=last;
		this.action=action;
		this.serverAddress=new InetSocketAddress(host,port);
	}
	
	public Client(String host,int port,String action,String username,String password) {//login
		
		this.username=username;
		this.password=password;
		this.action=action;
		this.serverAddress=new InetSocketAddress(host,port);
	}
	
	public Client(String action) {//logout ou matchmaking
		
		this.action=action;
	}
	
	public Client(String action,String newUsername,String newPassword) {//editar perfil
		
		this.username=newUsername;
		this.password=newPassword;
		this.action=action;
	}
	
	public static void main(String[] args) {
		
		
	}
	
	public void run() {

		try {
			Selector clientSelector=Selector.open();
			SocketChannel clientSocket = SocketChannel.open();
			clientSocket.configureBlocking(false);
			clientSocket.connect(serverAddress);
			clientSocket.register(clientSelector, SelectionKey.OP_CONNECT);
			
			while(true) {
				
				clientSelector.select();
				Iterator<SelectionKey> clientIterator=clientSelector.selectedKeys().iterator();
				
				while(clientIterator.hasNext()) {
					
					SelectionKey singleKey=(SelectionKey) clientIterator.next();
					clientIterator.remove();
					SocketChannel clientChannel=(SocketChannel) singleKey.channel();
					
					if(!singleKey.isValid())
						continue;
					
					if(singleKey.isConnectable()) {
						
						if(clientChannel.isConnectionPending()) {
							
							clientChannel.finishConnect();
							System.out.println("Cliente "+clientSocket.getLocalAddress()+" a ligar...");
						}
						clientChannel.register(clientSelector, SelectionKey.OP_WRITE);
						continue;
					}
					
					if(singleKey.isReadable()) {
						
						checkActionAndRead(clientChannel);
						clientChannel.register(clientSelector, SelectionKey.OP_WRITE);
						clientChannel.close();
						return;
					}
					
					if(singleKey.isWritable()) {
						
						checkActionAndWrite(clientChannel);
						clientChannel.register(clientSelector, SelectionKey.OP_READ);
					}
				}
			}
			
		} catch(IOException | InterruptedException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private String passwordChange(String password) {
		
		try {
			MessageDigest food=MessageDigest.getInstance("MD5");
			food.update(password.getBytes());
			byte[] bytes=food.digest();
			StringBuilder builder=new StringBuilder();
			
			for(int i=0;i<bytes.length;i++)
				builder.append(Integer.toString((bytes[i] & 0xff)+0x100,16).substring(1));
			
			hash=builder.toString();
			
		} catch(NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		
		return hash;
	}
	
	private void checkActionAndWrite(SocketChannel clientChannel) throws IOException, InterruptedException {
		
		if(Objects.equals("register",action)) {
			
			hash=passwordChange(password);
			Id idRequest=new Id(REGISTER);
			Register newUser=new Register(username,hash,first,last);
			sendObject(clientChannel,idRequest);
			TimeUnit.MILLISECONDS.sleep(100);
			sendObject(clientChannel,newUser);
		}
		
		if(Objects.equals("login",action)) {
			
			hash=passwordChange(password);
			Id idRequest=new Id(LOGIN);
			Login user=new Login(username,hash);
			sendObject(clientChannel,idRequest);
			TimeUnit.MILLISECONDS.sleep(100);
			sendObject(clientChannel,user);
		}
		
		if(Objects.equals("logout",action)) {
			
			
		}
		
		if(Objects.equals("editProfile",action)) {
			
			hash=passwordChange(password);
			Id idRequest=new Id(EDITPROFILE);
			Login user=new Login(username,hash);
			sendObject(clientChannel,idRequest);
			TimeUnit.MILLISECONDS.sleep(100);
			sendObject(clientChannel,user);
		}
	}
	
	private void checkActionAndRead(SocketChannel clientChannel) throws InterruptedException, ClassNotFoundException, IOException {
		
		if(Objects.equals("register",action)) {
			
			Object tmpObj=recvObject_IdType(clientChannel);
			int id=((Id) tmpObj).getIdRequest();
			
			if(id==REGISTER)
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Sucesso.");
			
			else if(id==ERROR)
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Erro.");
		}
		
		if(Objects.equals("login",action)) {
			
			Object tmpObj=recvObject_IdType(clientChannel);
			int id=((Id) tmpObj).getIdRequest();
			TimeUnit.MILLISECONDS.sleep(200);
			Object tmpObj2=recvObject_otherType(clientChannel,id);
			System.out.println(id);
			
			if(id==LOGIN) {
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Sucesso.");
				System.out.println(((UserProfile) tmpObj2).getFirst());
				System.out.println(((UserProfile) tmpObj2).getLast());
				System.out.println(((UserProfile) tmpObj2).getLeague());
				System.out.println(((UserProfile) tmpObj2).getCoins());
				System.out.println(((UserProfile) tmpObj2).getTotalduels());
				System.out.println(((UserProfile) tmpObj2).getTotalwins());
				System.out.println(((UserProfile) tmpObj2).getBestwinstreak());
				System.out.println(((UserProfile) tmpObj2).getHighestrank());
				System.out.println(((UserProfile) tmpObj2).getCurrentrank());
			}
			
			else if(id==ERROR)
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Erro.");
			
		}
		
		if(Objects.equals("logout",action)) {
			
			Object tmpObj=recvObject_IdType(clientChannel);
			int id=((Id) tmpObj).getIdRequest();
			
			if(id==LOGOUT)
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Sucesso.");
			
			else if(id==ERROR)
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Erro.");
		}	
		
		if(Objects.equals("editProfile",action)) {
			
			Object tmpObj=recvObject_IdType(clientChannel);
			int id=((Id) tmpObj).getIdRequest();
			
			if(id==EDITPROFILE)
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Sucesso.");
			
			else if(id==ERROR)
				System.out.println("Cliente "+clientChannel.getLocalAddress()+": Erro.");
		}
	}
	
	private void sendObject(SocketChannel clientChannel,Object sendObject) throws IOException {
		
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
		objectOutputStream.writeObject(sendObject);
		objectOutputStream.flush();
		clientChannel.write(ByteBuffer.wrap(byteArrayOutputStream.toByteArray()));	
	}
	
	private Object recvObject_IdType(SocketChannel clientChannel) throws IOException, ClassNotFoundException {
		
		ByteBuffer data = ByteBuffer.allocate(200);
		int numRead=clientChannel.read(data);
		if(numRead==0)
			return null;
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data.array());
		ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
		Id recvObject = (Id)objectInputStream.readObject();
		
		objectInputStream.close();
		return recvObject;
	}
	
	private Object recvObject_otherType(SocketChannel clientChannel, int id) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		UserProfile recvObject=null;
		ByteBuffer data = ByteBuffer.allocate(500);
		int numRead=clientChannel.read(data);
		if(numRead==0)
			return null;
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data.array());
		ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
		
		if(id==LOGIN){
			
			recvObject = (UserProfile)objectInputStream.readObject();
		}
		
		objectInputStream.close();
		return recvObject;
	}
}

/*
import java.util.*;
public class Strtok {

public static void main(String [] args) {

        String Demo = "This is a string that we want to tokenize";

        StringTokenizer Tok = new StringTokenizer(Demo);
        int n=0;

        while (Tok.hasMoreElements())
                System.out.println("" + ++n +": "+Tok.nextElement());
        }
}
*/